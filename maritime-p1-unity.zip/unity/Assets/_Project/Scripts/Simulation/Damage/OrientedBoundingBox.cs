using System;
using Mcis.Domain.Common;
using Mcis.Domain.Models;

namespace Mcis.Simulation.Damage
{
    /// <summary>水平面二维定向包围盒（船中心、首向、半长、半宽），用于船体净距计算。</summary>
    public readonly struct OrientedBoundingBox
    {
        public EnuPosition Center { get; }
        public double HeadingDeg { get; }
        public double HalfLengthM { get; }
        public double HalfBeamM { get; }

        public OrientedBoundingBox(EnuPosition center, double headingDeg, double halfLengthM, double halfBeamM)
        {
            Center = center;
            HeadingDeg = headingDeg;
            HalfLengthM = Math.Max(halfLengthM, 0.0);
            HalfBeamM = Math.Max(halfBeamM, 0.0);
        }

        public static OrientedBoundingBox FromVessel(EnuPosition center, double headingDeg, float loaM, float beamM)
        {
            return new OrientedBoundingBox(center, headingDeg, loaM * 0.5, beamM * 0.5);
        }

        /// <summary>船体局部 (forward, starboard) 轴的单位向量（ENU）。</summary>
        public void GetAxes(out Double2 forward, out Double2 starboard)
        {
            double rad = HeadingDeg * Math.PI / 180.0;
            double sin = Math.Sin(rad);
            double cos = Math.Cos(rad);
            forward = new Double2(sin, cos);
            starboard = new Double2(cos, -sin);
        }

        public Double2[] GetCorners()
        {
            Double2 f, s;
            GetAxes(out f, out s);
            var c = new Double2(Center.EastM, Center.NorthM);
            return new[]
            {
                c + f * HalfLengthM + s * HalfBeamM,
                c + f * HalfLengthM - s * HalfBeamM,
                c - f * HalfLengthM - s * HalfBeamM,
                c - f * HalfLengthM + s * HalfBeamM
            };
        }

        /// <summary>
        /// 计算两艘（或船与固定物）OBB 之间的最小净距。正值=分离距离，0=刚好接触，负值=穿透深度。
        /// 采用二维分离轴定理，并在分离时计算轴对齐的最小平移距离。
        /// </summary>
        public static double Clearance(OrientedBoundingBox a, OrientedBoundingBox b)
        {
            Double2 af, asb, bf, bsb;
            a.GetAxes(out af, out asb);
            b.GetAxes(out bf, out bsb);
            Double2 ca = new Double2(a.Center.EastM, a.Center.NorthM);
            Double2 cb = new Double2(b.Center.EastM, b.Center.NorthM);
            Double2 d = cb - ca;

            Double2[] axes = new[] { af, asb, bf, bsb };
            double minSeparation = double.PositiveInfinity;
            double minPenetration = double.PositiveInfinity;
            bool separated = false;

            for (int i = 0; i < axes.Length; i++)
            {
                Double2 axis = NormalizeOrZero(axes[i]);
                if (axis.LengthSquared < 1e-16)
                {
                    continue;
                }

                double projD = Math.Abs(Double2.Dot(d, axis));
                double ra = a.HalfLengthM * Math.Abs(Double2.Dot(af, axis)) + a.HalfBeamM * Math.Abs(Double2.Dot(asb, axis));
                double rb = b.HalfLengthM * Math.Abs(Double2.Dot(bf, axis)) + b.HalfBeamM * Math.Abs(Double2.Dot(bsb, axis));
                double gap = projD - (ra + rb);
                if (gap > 0.0)
                {
                    separated = true;
                    if (gap < minSeparation)
                    {
                        minSeparation = gap;
                    }
                }
                else
                {
                    double pen = -gap;
                    if (pen < minPenetration)
                    {
                        minPenetration = pen;
                    }
                }
            }

            if (separated)
            {
                return minSeparation == double.PositiveInfinity ? 0.0 : minSeparation;
            }

            return minPenetration == double.PositiveInfinity ? 0.0 : -minPenetration;
        }

        /// <summary>近似接触点：两中心连线与两盒边界的中点（用于报告）。</summary>
        public static EnuPosition ApproximateContact(OrientedBoundingBox a, OrientedBoundingBox b)
        {
            return new EnuPosition(
                0.5 * (a.Center.EastM + b.Center.EastM),
                0.5 * (a.Center.NorthM + b.Center.NorthM),
                0.5 * (a.Center.UpM + b.Center.UpM));
        }

        private static Double2 NormalizeOrZero(Double2 v)
        {
            double len = v.Length;
            if (len < 1e-12)
            {
                return Double2.Zero;
            }

            return v / len;
        }
    }

    /// <summary>船舶在某一时刻用于碰撞检测的运动学快照。</summary>
    public readonly struct CollisionBodyState
    {
        public string Id { get; }
        public EnuPosition Center { get; }
        public double HeadingDeg { get; }
        public Double2 VelocityEnuMps { get; }
        public float LoaM { get; }
        public float BeamM { get; }
        public float DisplacementTons { get; }
        public bool IsFixed { get; }

        public CollisionBodyState(
            string id,
            EnuPosition center,
            double headingDeg,
            Double2 velocityEnuMps,
            float loaM,
            float beamM,
            float displacementTons,
            bool isFixed = false)
        {
            Id = id ?? string.Empty;
            Center = center;
            HeadingDeg = headingDeg;
            VelocityEnuMps = velocityEnuMps;
            LoaM = loaM;
            BeamM = beamM;
            DisplacementTons = displacementTons;
            IsFixed = isFixed;
        }

        public OrientedBoundingBox Obb
        {
            get { return OrientedBoundingBox.FromVessel(Center, HeadingDeg, LoaM, BeamM); }
        }
    }
}
